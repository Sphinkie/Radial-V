# VMA11/MM100


This is a library for the Velleman VMA11 FM stereo arduino shield and the MM100 mini-module.  
It's a modified version of the sparkfun library.  
We've added non-blocking RDS functions.
