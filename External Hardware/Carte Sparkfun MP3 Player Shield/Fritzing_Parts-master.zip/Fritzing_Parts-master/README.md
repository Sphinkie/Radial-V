Fritzing_Parts
==============

This repo houses all of the SFE Fritzing parts for use in diagrams in tutorials. If you create a new part in Fritzing that correlates to an SFE part, please add it here so others may use it and to avoid duplication. 
